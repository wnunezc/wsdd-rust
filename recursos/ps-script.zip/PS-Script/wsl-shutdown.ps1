$ErrorActionPreference = 'Continue'

function Get-WslServiceName {
    foreach ($name in @('WslService', 'LxssManager')) {
        if (Get-Service -Name $name -ErrorAction SilentlyContinue) {
            return $name
        }
    }

    return $null
}

function Wait-ServiceStopped {
    param([string] $Name, [int] $TimeoutSeconds = 30)

    $waitUntil = [datetime]::Now.AddSeconds($TimeoutSeconds)
    do {
        $service = Get-Service -Name $Name -ErrorAction SilentlyContinue
        if ($null -eq $service -or $service.Status -eq 'Stopped') {
            return $true
        }
        Start-Sleep -Milliseconds 500
    } until ([datetime]::Now -ge $waitUntil)

    return $false
}

$serviceName = Get-WslServiceName

Write-Output 'STEP 1: Shutting down WSL instances'
wsl.exe --shutdown

if (-not [string]::IsNullOrWhiteSpace($serviceName)) {
    Write-Output "STEP 2: Stopping $serviceName"
    Stop-Service -Name $serviceName -Force -ErrorAction SilentlyContinue

    if (-not (Wait-ServiceStopped -Name $serviceName)) {
        Write-Warning 'Error: wsl-service-timeout'
        exit 1
    }
}

Write-Output 'Continue'
